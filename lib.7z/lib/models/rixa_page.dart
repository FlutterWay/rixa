import 'package:flutter/material.dart';
import 'package:rixa/models/page_base.dart';
import 'package:rixa/models/route_properties.dart';
import '../functions/functions.dart';

// ignore: must_be_immutable
class RixaPage extends PageBase {
  final String _name;
  final String _route;
  final Widget Function(BuildContext context, RouteProperties properties)?
      _builder;
  final Map<String, String>? _params;
  final String? _title;
  final String? Function(RouteProperties properties)? _redirect;
  final String? Function(RouteProperties properties)? _redirectedChild;
  final String Function(RouteProperties properties)? _description;

  String get name => _name;
  String get route => _route;
  String Function(RouteProperties properties)? get description => _description;
  Widget Function(BuildContext context, RouteProperties properties)?
      get builder => _builder;
  Map<String, String>? get params => _params;
  String? get title => _title;

  Function(RouteProperties properties)? get redirect => _redirect;
  Function(RouteProperties properties)? get redirectedChild => _redirectedChild;

  String get fullRoute {
    return parent == null ? _route : _addParentRoute(_route, parent!);
  }

  String _addParentRoute(String route, PageBase parent) {
    String newPath = parent is RixaPage ? parent.route + route : route;
    if (parent.parent != null) {
      return newPath = _addParentRoute(newPath, parent.parent!);
    } else {
      return newPath;
    }
  }

  String? redirectRoute(Map<String, String?> params, String route) {
    bool isValid = paramsConverter(path: route, params: params) ==
        paramsConverter(path: fullRoute, params: params);
    if (isValid && _redirect != null) {
      String? path = _redirect!(RouteProperties(
          route: paramsConverter(path: route, params: params),
          name: _name,
          params: _params));
      if (path != null) return path;
    }
    if (isValid && _redirectedChild != null) {
      String? path = _redirectedChild!(RouteProperties(
          route: paramsConverter(path: route, params: params),
          name: _name,
          params: _params));
      if (path != null) return "$fullRoute$path";
    } else {
      return null;
    }
    return null;
  }

  RixaPage({
    required String name,
    String? route,
    String Function(RouteProperties properties)? description,
    Widget Function(BuildContext context, RouteProperties properties)? builder,
    String? Function(RouteProperties properties)? redirect,
    String? Function(RouteProperties properties)? redirectedChild,
    Map<String, String>? params,
    String? title,
    super.children,
    super.screenModeLimits,
    super.fonts,
  })  : _name = name,
        _builder = builder,
        _redirect = redirect,
        _description = description,
        _redirectedChild = redirectedChild,
        _params = params,
        _title = title,
        _route = route ?? "/$name" {
    for (var child in children) {
      child.setParent = this;
    }
  }
}
