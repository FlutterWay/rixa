enum SizeType { small, medium, large, mega }
