enum DeviceType { mobile, desktop }

enum ScreenMode { mobile, landScape, desktopMini, desktopLarge }
