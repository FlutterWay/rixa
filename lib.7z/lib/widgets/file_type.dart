import 'package:boxicons/boxicons.dart';
import 'package:flutter/material.dart';

class FileTypeIcon extends StatelessWidget {
  final double size;
  final int typeIndex;
  late final dynamic icon;
  final List<Color> fileTypesColor = [
    const Color(0xFF6370fd),
    const Color(0xFFff6760),
    const Color(0xFFfdbe00),
  ];
  final List<Color> fileTypesBgColor = [
    const Color(0xFFeff0fe),
    const Color(0xFFffefee),
    const Color(0xFFe6faf3)
  ];

  FileTypeIcon({super.key, required this.typeIndex, required this.size}) {
    double iconSize = size * 0.6;
    if (typeIndex == 0) {
      icon = Icon(
        Icons.image_outlined,
        size: iconSize,
        color: fileTypesColor[typeIndex],
      );
    } else if (typeIndex == 1) {
      icon = Icon(
        Boxicons.bx_movie,
        size: iconSize,
        color: fileTypesColor[typeIndex],
      );
    } else {
      icon = Icon(
        Boxicons.bx_file,
        size: iconSize,
        color: fileTypesColor[typeIndex],
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
          color: fileTypesBgColor[typeIndex],
          borderRadius: BorderRadius.circular(7)),
      child: Center(
        child: icon,
      ),
    );
  }
}
