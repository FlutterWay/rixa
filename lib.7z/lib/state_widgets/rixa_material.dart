import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:rixa/models/page_base.dart';
import 'package:rixa/models/route_properties.dart';
import 'package:rixa/state_widgets/rixa_page_viewer.dart';
import '../functions/functions.dart';
import '../rixa.dart';
import 'global_middleware.dart';
import 'unknown_route_page.dart';

class RixaMaterial extends StatelessWidget {
  late final GoRouter router;
  late final List<GetPage> getPages;
  final GlobalKey<ScaffoldMessengerState>? scaffoldMessengerKey;
  final RouteInformationProvider? routeInformationProvider;
  final RouteInformationParser<Object>? routeInformationParser;
  final RouterDelegate<Object>? routerDelegate;
  final RouterConfig<Object>? routerConfig;
  final BackButtonDispatcher? backButtonDispatcher;
  final String title;
  final String Function(BuildContext)? onGenerateTitle;
  final Color? color;
  final ThemeData? theme;
  final ThemeData? darkTheme;
  final ThemeData? highContrastTheme, highContrastDarkTheme;
  final ThemeMode? themeMode;
  final Widget Function(BuildContext, Widget?)? builder;
  final Locale? locale;
  final Iterable<LocalizationsDelegate<dynamic>>? localizationsDelegates;
  final Locale? Function(List<Locale>?, Iterable<Locale>)?
      localeListResolutionCallback;
  final Locale? Function(Locale?, Iterable<Locale>)? localeResolutionCallback;
  final Iterable<Locale> supportedLocales;
  final bool debugShowMaterialGrid;
  final bool showPerformanceOverlay,
      checkerboardRasterCacheImages,
      checkerboardOffscreenLayers,
      showSemanticsDebugger,
      debugShowCheckedModeBanner,
      useInheritedMediaQuery;
  final Map<ShortcutActivator, Intent>? shortcuts;
  final Map<Type, Action<Intent>>? actions;
  final String? restorationScopeId;
  final ScrollBehavior? scrollBehavior;
  RixaMaterial({
    Key? key,
    this.scaffoldMessengerKey,
    this.routeInformationProvider,
    this.routeInformationParser,
    this.routerDelegate,
    this.routerConfig,
    this.backButtonDispatcher,
    this.title = '',
    this.onGenerateTitle,
    this.builder,
    this.color,
    this.theme,
    this.darkTheme,
    this.highContrastTheme,
    this.highContrastDarkTheme,
    this.themeMode = ThemeMode.system,
    this.locale,
    this.localizationsDelegates,
    this.localeListResolutionCallback,
    this.localeResolutionCallback,
    this.supportedLocales = const <Locale>[Locale('en', 'US')],
    this.debugShowMaterialGrid = false,
    this.showPerformanceOverlay = false,
    this.checkerboardRasterCacheImages = false,
    this.checkerboardOffscreenLayers = false,
    this.showSemanticsDebugger = false,
    this.debugShowCheckedModeBanner = true,
    this.shortcuts,
    this.actions,
    this.restorationScopeId,
    this.scrollBehavior,
    this.useInheritedMediaQuery = false,
  }) : super(key: key) {
    if (kIsWeb) {
      router = GoRouter(
        initialLocation: Get.find<PageManager>().initialRoute,
        routes: [
          for (var page in Get.find<PageManager>().pages)
            if (page is RixaPage)
              GoRoute(
                path: page.route,
                name: page.name,
                redirect: (context, state) =>
                    page.redirectRoute(state.params, state.location),
                pageBuilder: (context, state) {
                  Get.find<PageManager>().initRoute(
                      params: state.params,
                      route: paramsConverter(
                          path: page.route, params: state.params),
                      mainPage: page,
                      currentPage: page);
                  return CustomTransitionPage<void>(
                    key: state.pageKey,
                    child: page.builder != null
                        ? page.builder!(
                            context,
                            RouteProperties(
                                route: paramsConverter(
                                    path: page.route, params: state.params),
                                name: page.name,
                                params: state.params))
                        : Material(
                            child: Placeholder(
                              child: Center(
                                  child: Text(
                                "RixaPage named {${page.name}} doesn't have any builder!",
                                style: Rixa.appFonts.M(color: Colors.blue),
                              )),
                            ),
                          ),
                    transitionsBuilder:
                        (context, animation, secondaryAnimation, child) =>
                            FadeTransition(opacity: animation, child: child),
                  );
                },
                routes: getRoutes(
                    children: page.children, route: page.route, main: page),
              )
            else if (page is NestedPage)
              ShellRoute(
                builder: (context, state, widget) {
                  return page.builder(
                      context,
                      RouteProperties(
                          route: state.location,
                          name: "",
                          params: state.params),
                      widget);
                },
                routes:
                    getRoutes(children: page.children, route: "", main: null),
              )
        ],
        errorPageBuilder: (context, state) {
          Get.find<PageManager>()
              .initErrorPage(route: state.location, params: state.params);
          return CustomTransitionPage<void>(
            key: state.pageKey,
            child: Get.find<PageManager>().unknownRoutePage ??
                const UnknownRoutePage(),
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) =>
                    FadeTransition(opacity: animation, child: child),
          );
        },
      );
    } else {
      getPages = [
        GetPage(
          name: "/404",
          page: () =>
              Get.find<PageManager>().unknownRoutePage ??
              const UnknownRoutePage(),
        ),
        for (var page in Get.find<PageManager>().pages)
          if (page is RixaPage) ...[
            GetPage(
              name: page.route,
              page: () {
                {
                  Get.find<PageManager>().initRoute(
                      params: Get.parameters,
                      route: paramsConverter(
                          path: page.route, params: Get.parameters),
                      mainPage: page,
                      currentPage: page);
                  return RixaPageViewer(
                    rixaPage: page,
                    path: page.route,
                  );
                }
              },
              middlewares: [GlobalMiddleware()],
              children: convertToGetPages(
                  children: page.children, route: page.route, main: page),
            ),
          ] else if (page is NestedPage)
            for (var nestedChildPage in page.children) ...[
              GetPage(
                name: nestedChildPage.route,
                page: () {
                  {
                    Get.find<PageManager>().initRoute(
                        params: Get.parameters,
                        route: paramsConverter(
                            path: nestedChildPage.route,
                            params: Get.parameters),
                        mainPage: nestedChildPage,
                        currentPage: nestedChildPage);
                    return RixaNestedPageViewer(
                      nestedPage: page,
                      rixaPage: nestedChildPage,
                      path: nestedChildPage.route,
                    );
                  }
                },
                middlewares: [GlobalMiddleware()],
                children: convertToGetPages(
                    children: nestedChildPage.children, route: "", main: null),
              ),
            ]
      ];
    }
  }
  List<GetPage> convertToGetPages({
    required List<PageBase> children,
    required String route,
    required RixaPage? main,
  }) {
    return [
      for (var child in children)
        if (child is RixaPage) ...[
          GetPage(
            name: child.route,
            page: () {
              {
                NestedPage? nestedPage = child.firstNestedParent;
                Get.find<PageManager>().initRoute(
                    params: Get.parameters,
                    route: paramsConverter(
                        path: route + child.route, params: Get.parameters),
                    mainPage: main ?? child,
                    currentPage: child);
                if (nestedPage == null) {
                  return RixaPageViewer(
                      rixaPage: child, path: route + child.route);
                } else {
                  return RixaNestedPageViewer(
                    nestedPage: nestedPage,
                    rixaPage: child,
                    path: route + child.route,
                  );
                }
              }
            },
            children: convertToGetPages(
                children: child.children, route: child.route, main: child),
          ),
        ] else if (child is NestedPage)
          for (var nestedChildPage in child.children) ...[
            GetPage(
              name: nestedChildPage.route,
              page: () {
                {
                  Get.find<PageManager>().initRoute(
                      params: Get.parameters,
                      route: paramsConverter(
                          path: route + nestedChildPage.route,
                          params: Get.parameters),
                      mainPage: main ?? nestedChildPage,
                      currentPage: nestedChildPage);
                  return RixaNestedPageViewer(
                    nestedPage: child,
                    rixaPage: nestedChildPage,
                    path: route + nestedChildPage.route,
                  );
                }
              },
              children: convertToGetPages(
                  children: nestedChildPage.children, route: route, main: main),
            ),
          ]
    ];
  }

  List<RouteBase> getRoutes({
    required List<PageBase> children,
    required String route,
    required RixaPage? main,
  }) {
    return [
      for (var child in children)
        if (child is RixaPage)
          GoRoute(
            path:
                main == null ? child.route : child.route.replaceFirst("/", ""),
            name: child.name,
            redirect: (context, state) =>
                child.redirectRoute(state.params, state.location),
            pageBuilder: (context, state) {
              Get.find<PageManager>().initRoute(
                  params: state.params,
                  route: paramsConverter(
                      path: route + child.route, params: state.params),
                  mainPage: main ?? child,
                  currentPage: child);
              return CustomTransitionPage<void>(
                key: state.pageKey,
                child: child.builder != null
                    ? child.builder!(
                        context,
                        RouteProperties(
                            route: paramsConverter(
                                path: route + child.route,
                                params: state.params),
                            name: child.name,
                            params: state.params))
                    : Material(
                        child: Placeholder(
                          child: Center(
                              child: Text(
                            "RixaPage named {${child.name}} doesn't have any builder!",
                            style: Rixa.appFonts.M(color: Colors.blue),
                          )),
                        ),
                      ),
                transitionsBuilder:
                    (context, animation, secondaryAnimation, child) =>
                        FadeTransition(opacity: animation, child: child),
              );
            },
            routes: getRoutes(
                children: child.children,
                route: route + child.route,
                main: main ?? child),
          )
        else if (child is NestedPage)
          ShellRoute(
            builder: (context, state, widget) {
              return child.builder(
                  context,
                  RouteProperties(route: route, name: "", params: state.params),
                  widget);
            },
            routes:
                getRoutes(children: child.children, route: route, main: main),
          )
    ];
  }

  @override
  Widget build(BuildContext context) {
    if (kIsWeb) {
      return MaterialApp.router(
        routerConfig: router,
        scaffoldMessengerKey: scaffoldMessengerKey,
        routeInformationProvider: routeInformationProvider,
        routeInformationParser: routeInformationParser,
        routerDelegate: routerDelegate,
        backButtonDispatcher: backButtonDispatcher,
        builder: (context, child) => builder == null
            ? Stack(
                children: [
                  RixaPageBuilder(child: child!),
                  const EmojiGifMenuStack(),
                ],
              )
            : builder!(
                context,
                Stack(
                  children: [
                    RixaPageBuilder(child: child!),
                    const EmojiGifMenuStack(),
                  ],
                )),
        title: title,
        onGenerateTitle: onGenerateTitle,
        color: color,
        theme: theme,
        darkTheme: darkTheme,
        highContrastTheme: highContrastTheme,
        highContrastDarkTheme: highContrastDarkTheme,
        themeMode: themeMode,
        locale: locale,
        localizationsDelegates: localizationsDelegates,
        localeListResolutionCallback: localeListResolutionCallback,
        localeResolutionCallback: localeResolutionCallback,
        supportedLocales: supportedLocales,
        debugShowMaterialGrid: debugShowMaterialGrid,
        showPerformanceOverlay: showPerformanceOverlay,
        checkerboardRasterCacheImages: checkerboardRasterCacheImages,
        checkerboardOffscreenLayers: checkerboardOffscreenLayers,
        showSemanticsDebugger: showSemanticsDebugger,
        debugShowCheckedModeBanner: debugShowCheckedModeBanner,
        shortcuts: shortcuts,
        actions: actions,
        restorationScopeId: restorationScopeId,
        scrollBehavior: scrollBehavior,
        useInheritedMediaQuery: useInheritedMediaQuery,
      );
    } else {
      return GetMaterialApp(
        scaffoldMessengerKey: scaffoldMessengerKey,
        builder: (context, child) => builder == null
            ? Stack(
                children: [
                  RixaPageBuilder(child: child!),
                  const EmojiGifMenuStack(),
                ],
              )
            : builder!(
                context,
                Stack(
                  children: [
                    RixaPageBuilder(child: child!),
                    const EmojiGifMenuStack(),
                  ],
                )),
        initialRoute: Get.find<PageManager>().initialRoute,
        getPages: getPages,
        title: title,
        onGenerateTitle: onGenerateTitle,
        color: color,
        theme: theme,
        darkTheme: darkTheme,
        highContrastTheme: highContrastTheme,
        highContrastDarkTheme: highContrastDarkTheme,
        locale: locale,
        localizationsDelegates: localizationsDelegates,
        localeListResolutionCallback: localeListResolutionCallback,
        localeResolutionCallback: localeResolutionCallback,
        supportedLocales: supportedLocales,
        debugShowMaterialGrid: debugShowMaterialGrid,
        showPerformanceOverlay: showPerformanceOverlay,
        checkerboardRasterCacheImages: checkerboardRasterCacheImages,
        checkerboardOffscreenLayers: checkerboardOffscreenLayers,
        showSemanticsDebugger: showSemanticsDebugger,
        debugShowCheckedModeBanner: debugShowCheckedModeBanner,
        actions: actions,
        scrollBehavior: scrollBehavior,
        useInheritedMediaQuery: useInheritedMediaQuery,
      );
    }
  }
}
