import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/parse_route.dart';

import '../rixa.dart';

class GlobalMiddleware extends GetMiddleware {
  GlobalMiddleware();
  @override
  RouteSettings? redirect(String? route) {
    if (route != null) {
      Uri uri = Uri.parse(route);
      String keepParams = uri.toString();

      RouteDecoder match = Get.routeTree.matchRoute(keepParams);
      String path = match.treeBranch.last.name;
      if (path != route) {
        return const RouteSettings(name: "/404");
      } else {
        RixaPage? rixaPage = Get.find<PageManager>().searchGetxRoute(route);
        String? redirect = rixaPage?.redirectRoute(Get.parameters, route);
//
        return redirect == null || redirect == route
            ? null
            : RouteSettings(name: redirect);
      }
    } else {
      return null;
    }
  }
}
